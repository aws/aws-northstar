This example demonstrates how you can setup NorthStar in a React application created by [Create React App](https://reactjs.org/docs/create-a-new-react-app.html).  

To run the example, just install it and run:

```
yarn
yarn start
```
